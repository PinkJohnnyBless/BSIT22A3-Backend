﻿namespace backend.Models
{
    public class StudentResponceMessageClass
    {
        public string Status { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public String Data { get; set; } = String.Empty;
    }
}
